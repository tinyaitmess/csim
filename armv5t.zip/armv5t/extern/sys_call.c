#include <gliss/sys_call.h>

void swi_impl(int code)
{
	/* no system calls for the moment */
}
