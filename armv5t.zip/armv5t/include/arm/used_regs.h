/*
 * GLISS V2 -- used registers header template
 * Copyright (c) 2010, IRIT - UPS <casse@irit.fr>
 *
 * This file is part of GLISS V2.
 *
 * GLISS V2 is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * GLISS V2 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GLISS V2; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#ifndef ARM_USED_REGS
#define ARM_USED_REGS

#include "api.h"

/* register definition */
#define ARM_REG_COUNT	87
#define ARM_REG_USPSR(i)	((i) + 0)
#define ARM_REG_BBIT		5
#define ARM_REG_PBIT		9
#define ARM_REG_RBIT		10
#define ARM_REG_LBIT		11
#define ARM_REG_PSRFMODE		12
#define ARM_REG_GPR(i)	((i) + 14)
#define ARM_REG_WBIT		46
#define ARM_REG_PSRXMODE		48
#define ARM_REG_PSRSMODE		49
#define ARM_REG_IBIT		53
#define ARM_REG_UCPSR		55
#define ARM_REG_MSBIT		56
#define ARM_REG_B15SET		57
#define ARM_REG_UBIT		61
#define ARM_REG_PSRCMODE		62
#define ARM_REG_SBIT		64
#define ARM_REG_HBIT		65
#define ARM_REG_NPC		84


/* storage definition */
#define ARM_REG_READ_MAX		18
#define ARM_REG_WRITE_MAX		19
typedef int arm_used_regs_read_t[ARM_REG_READ_MAX + 1];
typedef int arm_used_regs_write_t[ARM_REG_WRITE_MAX + 1];

/* function declaration */
void arm_used_regs(arm_inst_t *inst, arm_used_regs_read_t regs, arm_used_regs_write_t wrs);

#endif /* ARM_USED_REGS */
