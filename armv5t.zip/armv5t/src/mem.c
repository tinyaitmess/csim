/*
 *	$Id: io_mem.c,v 1.8 2009/11/26 09:01:17 casse Exp $
 *	io_mem module implementation
 *
 *	This file is part of OTAWA
 *	Copyright (c) 2008, IRIT UPS.
 *
 *	GLISS is free software; you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation; either version 2 of the License, or
 *	(at your option) any later version.
 *
 *	GLISS is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with OTAWA; if not, write to the Free Software
 *	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

// swap commands
#ifdef _MSC_VER
#	include <stdlib.h>
#	define bswap_16(x) _byteswap_uint16(x)
#	define bswap_32(x) _byteswap_uint32(x)
#	define bswap_64(x) _byteswap_uint64(x)
#elif defined(__APPLE__)
#	include <libkern/OSByteOrder.h>
#	define bswap_16(x) OSSwapInt16(x)
#	define bswap_32(x) OSSwapInt32(x)
#	define bswap_64(x) OSSwapInt64(x)
#else
#	include <byteswap.h>
#endif

// fast modulo (y must be a power of 2)
#define FMOD(x, y)	((x) & ((y)-1))


/**
 * @defgroup memory Memory Module
 * A memory module is used to simulate the memory behaviour.
 * This module is mandatory and is only currently implemented by
 * the @ref io_mem .
 *
 * @author J. Barre, H. Casse, P. Sainrat
 *
 * @page io_mem	io_mem module
 *
 * This is a memory module acting like the fast_mem module, but you can specify a callback function
 * to be called in case of an access at a given page or address
 */

#define littl	0
#define big	1
#include "../include/arm/config.h"

/**
 * @def arm_address_t
 * This type represents a 32-bit address in memory space.
 * @ingroup memory
 */

/**
 * @typedef arm_memory_t
 * This type is used to represent a memory space.
 * @ingroup memory
 */

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include "../include/arm/mem.h"

#ifndef NDEBUG
#	define assertp(c, m)	\
		if(!(c)) { \
			fprintf(stderr, "assertiion failure %s:%d: %s", __FILE__, __LINE__, m); \
			abort(); }
#else
#	define assertp(c, m)
#endif


#ifndef TARGET_ENDIANNESS
#	error "TARGET_ENDIANNESS must be defined !"
#endif

#ifndef HOST_ENDIANNESS
#	error "HOST_ENDIANNESS must be defined !"
#endif
/*
#if TARGET_ENDIANNESS == HOST_ENDIANNESS
#	info "endianness equals"
#else
#	info "endianness different"
#endif*/



/* callback infos, to be remembered as pages are created only when first accessed */

typedef struct arm_callback_info_t {
	arm_address_t start;
	arm_address_t end;
	arm_callback_fun_t callback_fun;
	void *callback_data ;
	struct arm_callback_info_t *next;
} arm_callback_info_t;

typedef struct
{
	arm_callback_info_t *ptr;
	int is_changed;
} arm_callback_info_table_t;


/* MEMORY REPRESENTATION */

/* WARNING: constant below be multiple of 8 bytes ! */

/* memory page size */
#define MEMORY_PAGE_SIZE 4096
/* primary hash table size */
#define PRIMARYMEMORY_HASH_TABLE_SIZE 4096
/* secondary hash table size */
#define SECONDARYMEMORY_HASH_TABLE_SIZE 16

/*
 * Memory is allocated dynamically when needed.
 * The memory is organized as:
 *
 *  |-------------|
 *  |             |
 *  |-------------|
 *  |             |
 *  |-------------|
 *  |             |
 *  |-------------|
 *  |      -------|------->|-------|
 *  |-------------|        |   ----|---> list of pairs(address +
 *  |             |        |-------|                   MEMORY_PAGE_SIZE bytes)
 *  |-------------|        |       |
 *  |             |        |-------|
 *  |-------------|          ....
 *  |             |
 *  |-------------|
 *      ....
 *   ^ primary hastable       ^ secondary hashtable
 *
 * the hash method works as :
 *
 * memory address is hashed like that
 *
 *  ..----|----|------------|------------|
 *     4    3        2            1
 * 1 -> the address inside the page
 * 2 -> the address corresponding to the primary hash code
 * 3 -> the address corresponding to the secondary hash code
 * 4 -> inside the "list of pairs" described overhead
 */
typedef struct memory_page_table_entry_t  {
	arm_address_t addr;
	struct memory_page_table_entry_t *next;
	uint8_t *storage;
	/* callback function for IO, 0 if no callback */
	arm_callback_info_t *info;
} memory_page_table_entry_t;

typedef struct  {
	memory_page_table_entry_t *pte[SECONDARYMEMORY_HASH_TABLE_SIZE];
} secondary_memory_hash_table_t;

struct arm_memory_t {
	void* image_link; /* link to a generic image data resource of the memory
	                     it permits to fetch informations about image structure
	                     via an optionnal external system */
    secondary_memory_hash_table_t *primary_hash_table[PRIMARYMEMORY_HASH_TABLE_SIZE];
    /* infos about callback functions */
    arm_callback_info_table_t callback_infos;
#ifdef ARM_MEM_SPY
	arm_mem_spy_t spy_fun;	/** spy function */
	void *spy_data;				/** spy data */
#endif
};
typedef struct arm_memory_t memory_64_t;


#ifdef ARM_MEM_SPY
/**
 * Default spy function: do nothing.
 */
static void arm_mem_default_spy(arm_memory_t *mem, arm_address_t addr, arm_size_t size, arm_access_t access, void *data) {
}
#endif


/**
 * Compute hash level 1.
 * @param addr	Address to hash.
 * @return		Hash value.
 */
static uint32_t mem_hash1(arm_address_t addr)  {
    return (addr / MEMORY_PAGE_SIZE) % PRIMARYMEMORY_HASH_TABLE_SIZE;
}


/**
 * Compute hash level 2.
 * @param addr	Address to hash.
 * @return		Hash value.
 */
static uint32_t mem_hash2(arm_address_t addr)  {
    return (addr / MEMORY_PAGE_SIZE / PRIMARYMEMORY_HASH_TABLE_SIZE) % SECONDARYMEMORY_HASH_TABLE_SIZE;
}


/**
 * Initialize the memory structure.
 * @param mem	Memory o initialize.
 */
static void arm_mem_init(memory_64_t *mem) {
	memset(mem->primary_hash_table,0,sizeof(mem->primary_hash_table));
	mem->image_link = NULL;
	mem->callback_infos.ptr = 0;
	mem->callback_infos.is_changed = 0;
#	ifdef ARM_MEM_SPY
		mem->spy_fun = arm_mem_default_spy;
		mem->spy_data = 0;
#	endif
}


/**
 * Build a new memory handler.
 * @return	Memory handler or NULL if there is not enough memory.
 * @ingroup memory
 */
arm_memory_t *arm_mem_new(void) {
    memory_64_t *mem;
    mem = (memory_64_t *)malloc(sizeof(memory_64_t));
    if(mem != NULL)
		arm_mem_init(mem);
	return (arm_memory_t *)mem;
}


#ifdef ARM_MEM_SPY
/**
 * Set the spy function on the given memory. This function will be called
 * at each memory access with the details of the memory transaction.
 * @param mem	Current memory.
 * @param fun	Function called at each memory access.
 * @param data	Data passed as the last argument when function fun is called.
 */
void arm_mem_set_spy(arm_memory_t *mem, arm_mem_spy_t fun, void *data) {
	assert(mem);
	if(!fun) {
		mem->spy_fun = arm_mem_default_spy;
		mem->spy_data = 0;
	}
	else {
		mem->spy_fun = fun;
		mem->spy_data = data;
	}
}
#endif



/**
 * Clean the used pages..
 * @param memory	Memory to delete.
 * @ingroup memory
 */
void arm_mem_clean(arm_memory_t *memory) {
	int i,j;
	secondary_memory_hash_table_t *secondary_hash_table;
	memory_page_table_entry_t *pte;
	memory_page_table_entry_t *nextpte;
	memory_64_t *mem64 = (memory_64_t *)memory;

	/* get right type */
	for (i=0; i<PRIMARYMEMORY_HASH_TABLE_SIZE;i++)  {
		secondary_hash_table = mem64->primary_hash_table[i];
		if(secondary_hash_table) {
			for(j=0;j<SECONDARYMEMORY_HASH_TABLE_SIZE;j++) {
				pte=secondary_hash_table->pte[j];
				while (pte) {
					nextpte=pte->next;
					free(pte->storage);
					free(pte);	/* freeing each page */
					pte=nextpte;
				}
			}
			free(secondary_hash_table); /* freeing each secondary hash table */
		}
	}

	/* free the callback list */
	memory->callback_infos.ptr = 0;
	arm_callback_info_t *info_ptr = memory->callback_infos.ptr;
	arm_callback_info_t *next_ptr = 0;
	while (info_ptr)
	{
		next_ptr = info_ptr->next;
		free(info_ptr);
		info_ptr = next_ptr;
	}
}


/**
 * Free and delete the given memory.
 * @param memory	Memory to delete.
 * @ingroup memory
 */
void arm_mem_delete(arm_memory_t *memory) {
	arm_mem_clean(memory);
	free((memory_64_t *)memory);
}


/**
 * Reset the memory to its initial state (including callbacks).
 * @param memory		Memory to reset.
 */
void arm_mem_reset(arm_memory_t *memory) {
	arm_mem_clean(memory);
	arm_mem_init(memory);
}


/**
 * Copy the current memory.
 * @param memory	Memory to copy.
 * @return			Copied memory or null if there is not enough memory.
 * @ingroup memory
 */
/* !!TODO!! implement copy of callback info */
arm_memory_t *arm_mem_copy(arm_memory_t *memory) {
	int i,j;
	memory_64_t *mem = memory, *target;

	/* allocate memory */
	target = arm_mem_new();
	if(target == NULL)
		return NULL;

	/* copy memory */
	for(i=0;i<PRIMARYMEMORY_HASH_TABLE_SIZE;i++) {
		secondary_memory_hash_table_t *secondary_hash_table = mem->primary_hash_table[i];
		if(secondary_hash_table) {
			for(j=0;j<SECONDARYMEMORY_HASH_TABLE_SIZE;j++) {
				memory_page_table_entry_t *pte=secondary_hash_table->pte[i];
				if(pte) {
					do {
						arm_mem_write(target, pte->addr, pte->storage, MEMORY_PAGE_SIZE);
					} while((pte=pte->next) != 0);
				}
			}
		}
	}
	return target;
}


/**
 * Look for a page in memory.
 * @param mem	Memory to work on.
 * @param addr	Address of the looked page.
 * @ingroup memory
 */
static memory_page_table_entry_t *mem_search_page(memory_64_t *mem, arm_address_t addr) {
	uint32_t h1;
	uint32_t h2;
	secondary_memory_hash_table_t *secondary_hash_table;
	memory_page_table_entry_t *pte;

	/* computes the first adress of the page */
	addr = addr - (addr%MEMORY_PAGE_SIZE);
	h1 = mem_hash1(addr);
	secondary_hash_table = mem->primary_hash_table[h1];

	/* if the secondary hash table exists */
	if(secondary_hash_table) {

		h2 = mem_hash2(addr);
		pte = secondary_hash_table->pte[h2];

		/* search the page entry */
		if(pte) {
			do  {
				if(pte->addr==addr)
                	return pte;
			} while((pte=pte->next)!=0);
		}
	}
	return 0;
}


/**
 * Get a secondary page table.
 * @parm mem	Memory to work on.
 * @param addr	Address of the page.
 */
static secondary_memory_hash_table_t* mem_get_secondary_hash_table(
	memory_64_t *mem,
	arm_address_t addr)
{
	uint32_t h1;
	secondary_memory_hash_table_t* secondary_hash_table;

	/* try to fetch the secondary hashtable */
	h1 = mem_hash1(addr);
	secondary_hash_table = mem->primary_hash_table[h1];

	/* if the secondary hashtable does'nt exists */
	if(!secondary_hash_table) {
		/* allocation of the secondary hashtable */
		secondary_hash_table = (secondary_memory_hash_table_t *)
			calloc(sizeof(secondary_memory_hash_table_t),1);

		assertp(secondary_hash_table != NULL,
			"Failed to allocate memory in mem_get_secondary_hash_table\n");
		mem->primary_hash_table[h1]=secondary_hash_table;
	}

	return secondary_hash_table;
}


static void update_callback_infos(arm_memory_t *mem);
static arm_callback_info_t *get_callback_info(arm_callback_info_table_t *infos, arm_address_t addr);

/**
 * Get the page matching the given address and create it if it does not exist.
 * @parm mem	Memory to work on.
 * @param addr	Address of the page.
 */
static memory_page_table_entry_t *mem_get_page(memory_64_t *mem, arm_address_t addr) {
	memory_page_table_entry_t *pte;
	uint32_t h2; /* secondary hash table entry # value */
	secondary_memory_hash_table_t *secondary_hash_table;

	/* is there any new callback info? */
	if (mem->callback_infos.is_changed)
		update_callback_infos(mem);

	/* search the page */
	addr = addr - (addr%MEMORY_PAGE_SIZE);
	pte = mem_search_page(mem,addr);

	/* if the page doesn't yet exists */
	if(!pte)  {
		secondary_hash_table = mem_get_secondary_hash_table(mem, addr);
		h2 = mem_hash2(addr);

		/* allocation of the page entry descriptor */
		pte = (memory_page_table_entry_t *)malloc(sizeof(memory_page_table_entry_t));
		assertp(pte != NULL, "Failed to allocate memory in mem_get_page\n");
		pte->addr = addr;

		/* allocation of the page */
		pte->storage = (uint8_t *)calloc(MEMORY_PAGE_SIZE,1);
		assertp(pte->storage != NULL, "Failed to allocate memory in mem_get_page\n");

		/* set callback function */
		pte->info = get_callback_info(&mem->callback_infos, addr);

		/* adding the memory page to the list of memory page size entry*/
		pte->next = secondary_hash_table->pte[h2];
		secondary_hash_table->pte[h2]=pte;
	}
	return pte;
}


/**
 * Write a buffer into memory.
 * @param memory	Memory to write into.
 * @param address	Address in memory to write to.
 * @param buffer	Buffer address in host memory.
 * @param size		Size of the buffer to write.
 * @ingroup memory
 */
void arm_mem_write(arm_memory_t *memory, arm_address_t address, void *buffer, size_t size) {
	if(size>0) {
		memory_64_t *mem = (memory_64_t *)memory;
		uint32_t offset = address % MEMORY_PAGE_SIZE;
		memory_page_table_entry_t *pte = mem_get_page(mem, address);
        uint32_t sz = MEMORY_PAGE_SIZE - offset;
        if(size > sz) {
			memcpy(pte->storage+offset, buffer, sz);
			size -= sz;
			address += sz;
			buffer = (uint8_t *)buffer + sz;
			if(size>=MEMORY_PAGE_SIZE) {
				do {
					pte = mem_get_page(mem, address);
					memcpy(pte->storage, buffer, MEMORY_PAGE_SIZE);
					size -= MEMORY_PAGE_SIZE;
					address += MEMORY_PAGE_SIZE;
					buffer = (uint8_t *)buffer + MEMORY_PAGE_SIZE;
				} while(size >= MEMORY_PAGE_SIZE);
			}
			if(size > 0) {
				pte=mem_get_page(mem, address);
				memcpy(pte->storage, buffer, size);
			}
        }
		else
			memcpy(pte->storage + offset, buffer, size);
    }

#	ifdef ARM_MEM_SPY
    	memory->spy_fun(memory, address, size, arm_access_write, memory->spy_data);
#	endif
}


/**
 * Read the memory into the given buffer.
 * @param memory	Memory to read in.
 * @param address	Address of the data to read.
 * @param buffer	Buffer to write data in.
 * @param size		Size of the data to read.
 * @ingroup memory
 */
void arm_mem_read(arm_memory_t *memory, arm_address_t address, void *buffer, size_t size) {
	if(size > 0) {
		memory_64_t *mem = (memory_64_t *) memory;
		uint32_t offset = address % MEMORY_PAGE_SIZE;
		memory_page_table_entry_t *pte = mem_get_page(mem, address);
		uint32_t sz = MEMORY_PAGE_SIZE - offset;
		if(size > sz) {
			memcpy(buffer, pte->storage + offset, sz);
			size -= sz;
            address += sz;
			buffer = (uint8_t *)buffer + sz;
			if(size >= MEMORY_PAGE_SIZE) {
				do {
					pte = mem_get_page(mem, address);
					memcpy(buffer, pte->storage, MEMORY_PAGE_SIZE);
					size -= MEMORY_PAGE_SIZE;
					address += MEMORY_PAGE_SIZE;
					buffer = (uint8_t *)buffer + MEMORY_PAGE_SIZE;
				} while(size >= MEMORY_PAGE_SIZE);
			}
			if(size>0) {
				pte = mem_get_page(mem, address);
				memcpy(buffer, pte->storage, size);
			}
		}
		else
			memcpy(buffer, pte->storage + offset, size);
    }

#	ifdef ARM_MEM_SPY
    	memory->spy_fun(memory, address, size, arm_access_read, memory->spy_data);
#	endif
}


/**
 * Read an 8-bit integer.
 * @param memory	Memory to work with.
 * @param address	Address of integer to read.
 * @return			Read integer.
 * @ingroup memory
 */
uint8_t arm_mem_read8(arm_memory_t *memory, arm_address_t address) {
	memory_64_t *mem = (memory_64_t *)memory;
	arm_address_t offset = address % MEMORY_PAGE_SIZE;
	memory_page_table_entry_t *pte = mem_get_page(mem, address);

	/* support of callback */
	uint8_t res;
	if(pte->info)
		pte->info->callback_fun(address, 1, &res, ARM_MEM_READ, pte->info->callback_data);
	else
		res = pte->storage[offset];
#	ifdef ARM_MEM_SPY
    	memory->spy_fun(memory, address, sizeof(res), arm_access_read, memory->spy_data);
#	endif
    return res;
}


/**
 * Read a 16-bit integer.
 * @param memory	Memory to work with.
 * @param address	Address of integer to read.
 * @return			Read integer.
 * @ingroup memory
 */
uint16_t arm_mem_read16(arm_memory_t *memory, arm_address_t address) {
	typedef uint16_t T;
#	define BSWAP(x)	bswap_16(x)
	union {
		uint8_t bytes[sizeof(T)];
		T word;
	} val;
    T r;

	/* get page */
    arm_address_t offset = FMOD(address, MEMORY_PAGE_SIZE);
    memory_page_table_entry_t *pte = mem_get_page(memory, address);

	/* is it IO? */
	if (pte->info)
		pte->info->callback_fun(address, sizeof(T), &r, ARM_MEM_READ, pte->info->callback_data);

	/* straight read */
	else {
    	uint8_t* p = pte->storage + offset;

		/* read the bytes */
		if(!((offset & (sizeof(T)-1)) | ((offset + (sizeof(T)-1)) & MEMORY_PAGE_SIZE)))
			val.word = *(T *)p;
		else
			arm_mem_read(memory, address, val.bytes, sizeof(T));

		/* possibly change order */
#		if HOST_ENDIANNESS == TARGET_ENDIANNESS
			r = val.word;
#		else
			r = BSWAP(val.word);
#		endif
	}

#	ifdef ARM_MEM_SPY
    	mem->spy_fun(memory, address, sizeof(T), arm_access_read, mem->spy_data);
#	endif
    return r;
#	undef BSWAP
}


/**
 * Read a 32-bit integer.
 * @param memory	Memory to work with.
 * @param address	Address of integer to read.
 * @return			Read integer.
 * @ingroup memory
 */
uint32_t arm_mem_read32(arm_memory_t *memory, arm_address_t address) {
	typedef uint32_t T;
#	define BSWAP(x)	bswap_32(x)
	union {
		uint8_t bytes[sizeof(T)];
		T word;
	} val;
    T r;

	/* get page */
    arm_address_t offset = FMOD(address, MEMORY_PAGE_SIZE);
    memory_page_table_entry_t *pte = mem_get_page(memory, address);

	/* is it IO? */
	if (pte->info)
		pte->info->callback_fun(address, sizeof(T), &r, ARM_MEM_READ, pte->info->callback_data);

	/* straight read */
	else {
    	uint8_t* p = pte->storage + offset;

		/* read the bytes */
		if(!((offset & (sizeof(T)-1)) | ((offset + (sizeof(T)-1)) & MEMORY_PAGE_SIZE)))
			val.word = *(T *)p;
		else
			arm_mem_read(memory, address, val.bytes, sizeof(T));

		/* possibly change order */
#		if HOST_ENDIANNESS == TARGET_ENDIANNESS
			r = val.word;
#		else
			r = BSWAP(val.word);
#		endif
	}

#	ifdef ARM_MEM_SPY
    	mem->spy_fun(memory, address, sizeof(T), arm_access_read, mem->spy_data);
#	endif
    return r;
#	undef BSWAP
}


/**
 * Read a 64-bit integer.
 * @param memory	Memory to work with.
 * @param address	Address of integer to read.
 * @return			Read integer.
 * @ingroup memory
 */
uint64_t arm_mem_read64(arm_memory_t *memory, arm_address_t address) {
	typedef uint64_t T;
#	define BSWAP(x)	bswap_64(x)
	union {
		uint8_t bytes[sizeof(T)];
		T word;
	} val;
    T r;

	/* get page */
    arm_address_t offset = FMOD(address, MEMORY_PAGE_SIZE);
    memory_page_table_entry_t *pte = mem_get_page(memory, address);

	/* is it IO? */
	if (pte->info)
		pte->info->callback_fun(address, sizeof(T), &r, ARM_MEM_READ, pte->info->callback_data);

	/* straight read */
	else {
    	uint8_t* p = pte->storage + offset;

		/* read the bytes */
		if(!((offset & (sizeof(T)-1)) | ((offset + (sizeof(T)-1)) & MEMORY_PAGE_SIZE)))
			val.word = *(T *)p;
		else
			arm_mem_read(memory, address, val.bytes, sizeof(T));

		/* possibly change order */
#		if HOST_ENDIANNESS == TARGET_ENDIANNESS
			r = val.word;
#		else
			r = BSWAP(val.word);
#		endif
	}

#	ifdef ARM_MEM_SPY
    	mem->spy_fun(memory, address, sizeof(T), arm_access_read, mem->spy_data);
#	endif
    return r;
#	undef BSWAP
}


/**
 * Read a float value.
 * @param memory	Memory to work with.
 * @param address	Address of float to read.
 * @return			Read float.
 * @ingroup memory
 */
float arm_mem_readf(arm_memory_t *memory, arm_address_t address) {
	union {
		uint32_t i;
		float f;
	} val;
	val.i = arm_mem_read32(memory, address);
	return val.f;
}



/**
 * Read a double float value.
 * @param memory	Memory to work with.
 * @param address	Address of float to read.
 * @return			Read float.
 * @ingroup memory
 */
double arm_mem_readd(arm_memory_t *memory, arm_address_t address) {
	union {
		uint64_t i;
		double f;
	} val;
	val.i = arm_mem_read64(memory, address);
	return val.f;
}


/**
 * Read a long double float value.
 * @param memory	Memory to work with.
 * @param address	Address of float to read.
 * @return			Read float.
 * @ingroup memory
 */
long double arm_mem_readld(arm_memory_t *memory, arm_address_t address) {
	assertp(0, "not implemented !");
}


/**
 * Write an 8-bit integer in memory.
 * @param memory	Memory to write in.
 * @param address	Address to write integer to.
 * @param val		Integer to write.
 * @ingroup memory
 */
void arm_mem_write8(arm_memory_t *memory, arm_address_t address, uint8_t val) {
	memory_64_t *mem = (memory_64_t *)memory;
	arm_address_t offset;
	memory_page_table_entry_t *pte;
	offset = address % MEMORY_PAGE_SIZE;
	pte = mem_get_page(mem, address);
	pte->storage[offset] = val;
	/* do callback if available */
	if(pte->info) {
		uint8_t res = val;
		pte->info->callback_fun(address, 1, &val, ARM_MEM_WRITE, pte->info->callback_data);
	}
#	ifdef ARM_MEM_SPY
    	mem->spy_fun(mem, address, sizeof(val), arm_access_write, mem->spy_data);
#	endif
}


/**
 * Write a 16-bit integer in memory.
 * @param memory	Memory to write in.
 * @param address	Address to write integer to.
 * @param val		Integer to write.
 * @ingroup memory
 */
void arm_mem_write16(arm_memory_t *memory, arm_address_t address, uint16_t val) {
	memory_64_t *mem = (memory_64_t *)memory;
	arm_address_t offset;
	union val_t {
		uint8_t bytes[2];
		uint16_t half;
	} *p = (union val_t *)&val;
	uint16_t *q;

	/* compute address */
	memory_page_table_entry_t *pte;
	offset = address % MEMORY_PAGE_SIZE;
	pte = mem_get_page(mem, address);
	q = (uint16_t *)(pte->storage + offset);

	/* invert ? */
#	if HOST_ENDIANNESS != TARGET_ENDIANNESS
	{
		uint8_t a = p->bytes[0];
		p->bytes[0] = p->bytes[1];
		p->bytes[1] = a;
	}
#	endif

	/* aligned ? */
	if((address & 0x00000001) == 0)
		*q = p->half;
	else
		memcpy(q, p->bytes, 2);

	if (pte->info)
		pte->info->callback_fun(address, 2, q, ARM_MEM_WRITE, pte->info->callback_data);
#	ifdef ARM_MEM_SPY
    	mem->spy_fun(mem, address, sizeof(val), arm_access_write, mem->spy_data);
#	endif
}


/**
 * Write a 32-bit integer in memory.
 * @param memory	Memory to write in.
 * @param address	Address to write integer to.
 * @param val		Integer to write.
 * @ingroup memory
 */
void arm_mem_write32(arm_memory_t *memory, arm_address_t address, uint32_t val) {
	memory_64_t *mem = (memory_64_t *)memory;
	arm_address_t offset;
	union val_t {
		uint8_t bytes[4];
		uint32_t word;
	} *p = (union val_t *)&val;
	uint32_t *q;

	/* compute address */
	memory_page_table_entry_t *pte;
	offset = address % MEMORY_PAGE_SIZE;
	pte = mem_get_page(mem, address);
	q = (uint32_t *)(pte->storage + offset);

	/* invert ? */
#	if HOST_ENDIANNESS != TARGET_ENDIANNESS
	{
		uint8_t a = p->bytes[0];
		p->bytes[0] = p->bytes[3];
		p->bytes[3] = a;
		a = p->bytes[1];
		p->bytes[1] = p->bytes[2];
		p->bytes[2] = a;
	}
#	endif

	/* aligned ? */
	if((address & 0x00000003) == 0)
		*q = p->word;
	else
		memcpy(q, p->bytes, 4);

	if (pte->info)
		pte->info->callback_fun(address, 4, q, ARM_MEM_WRITE, pte->info->callback_data);
#	ifdef ARM_MEM_SPY
    	mem->spy_fun(mem, address, sizeof(val), arm_access_write, mem->spy_data);
#	endif
}


/**
 * Write a 64-bit integer in memory.
 * @param memory	Memory to write in.
 * @param address	Address to write integer to.
 * @param val		Integer to write.
 * @ingroup memory
 */
void arm_mem_write64(arm_memory_t *memory, arm_address_t address, uint64_t val) {
	memory_64_t *mem = (memory_64_t *)memory;
	arm_address_t offset;
	union val_t {
		uint8_t bytes[8];
		uint64_t dword;
	} *p = (union val_t *)&val;
	uint64_t *q;

	/* compute address */
	memory_page_table_entry_t *pte;
	offset = address % MEMORY_PAGE_SIZE;
	pte = mem_get_page(mem, address);
	q = (uint64_t *)(pte->storage + offset);

	/* invert ? */
#	if HOST_ENDIANNESS != TARGET_ENDIANNESS
	{
		uint8_t a = p->bytes[0];
		p->bytes[0] = p->bytes[7];
		p->bytes[7] = a;
		a = p->bytes[1];
		p->bytes[1] = p->bytes[6];
		p->bytes[6] = a;
		a = p->bytes[2];
		p->bytes[2] = p->bytes[5];
		p->bytes[5] = a;
		a = p->bytes[3];
		p->bytes[3] = p->bytes[4];
		p->bytes[4] = a;
	}
#	endif

	/* aligned ? */
	if((address & 0x00000007) == 0)
		*q = p->dword;
	else
		memcpy(q, p->bytes, 8);

	if (pte->info)
		pte->info->callback_fun(address, 8, q, ARM_MEM_WRITE, pte->info->callback_data);
#	ifdef ARM_MEM_SPY
    	mem->spy_fun(mem, address, sizeof(val), arm_access_write, mem->spy_data);
#	endif
}


/**
 * Write a float in memory.
 * @param memory	Memory to write in.
 * @param address	Address to write float to.
 * @param val		Float to write.
 * @ingroup memory
 */
void arm_mem_writef(arm_memory_t *memory, arm_address_t address, float val) {
	union {
		uint32_t i;
		float f;
	} v;
	v.f = val;
	arm_mem_write32(memory, address, v.i);
}


/**
 * Write a double float in memory.
 * @param memory	Memory to write in.
 * @param address	Address to write float to.
 * @param val		Float to write.
 * @ingroup memory
 */
void arm_mem_writed(arm_memory_t *memory, arm_address_t address, double val) {
	union {
		uint64_t i;
		double f;
	} v;
	v.f = val;
	arm_mem_write64(memory, address, v.i);
}


/**
 * Write a double float in memory.
 * @param memory	Memory to write in.
 * @param address	Address to write float to.
 * @param val		Float to write.
 * @ingroup memory
 */
void arm_mem_writeld(arm_memory_t *memory, arm_address_t address, long double val) {
	assertp(0, "not implemented");
}


/**
 * Search the given callback info list if there's anything concerning the given address,
 * return the address of callback information, 0 if no callback is defined for that address.
 * @param infos		Callback information table.
 * @param addr		Page addresse.
 */
static arm_callback_info_t *get_callback_info(arm_callback_info_table_t *infos, arm_address_t addr)
{
	arm_callback_info_t *ptr = infos->ptr;
	while(ptr) {
		if( ((ptr->start <= addr) && (addr <= ptr->end))
		||  ((ptr->start <= (addr+MEMORY_PAGE_SIZE-1)) && ((addr+MEMORY_PAGE_SIZE-1) <= ptr->end)))
			return ptr;
		ptr = ptr->next;
	}
	return 0;
}


/**
 * Update callback infos for the given memory, for all already created pages
 * we set correctly the callback function address accordingly to the callback infos of the given memory.
 */
static void update_callback_infos(arm_memory_t *mem)
{
	int i, j;

	/* go through pages */
	for (i = 0 ; i < PRIMARYMEMORY_HASH_TABLE_SIZE ; i++) {
		secondary_memory_hash_table_t *secondary_hash_table = mem->primary_hash_table[i];
		if (secondary_hash_table) {
			for (j = 0 ; j < SECONDARYMEMORY_HASH_TABLE_SIZE ; j++) {
				memory_page_table_entry_t *pte = secondary_hash_table->pte[j];
				if (pte) {
					do {
						/* get callback info for beginning of page, let's hope the whole page has the same callback function */
						pte->info = get_callback_info(&mem->callback_infos, pte->addr);
					} while ((pte=pte->next) != 0);
				}
			}
		}
	}
	/* nothing more to update */
	mem->callback_infos.is_changed = 0;
}


/**
 * set a callback function for a specified range of memory supposed to be used to map an IO peripheric.
 * As memory is divided in pages, the range will be extended to all the pages covering the given range.
 * Warning: overlap could happen between the normal memory and the bypassed one
 * @param mem		Memory to bypass
 * @param start		physical address of the start of the range to bypass
 * @param end		physical address of the end of the range to bypass
 * @param f		callback function bypassing the usual behavior
 * @ingroup memory
 */
void arm_set_range_callback(arm_memory_t *mem, arm_address_t start, arm_address_t end, arm_callback_fun_t f, void* data){
	/* store the infos in callback infos table */

	/* create new entry */
	arm_callback_info_t *new_info = malloc(sizeof(arm_callback_info_t));
	assertp(new_info, "malloc error for arm_callback_info_t");
	new_info->start = start;
	new_info->end = end;
	new_info->callback_fun = f;
	new_info->callback_data = data ;
	/* insert at beginning of the current list */
	new_info->next = mem->callback_infos.ptr;
	mem->callback_infos.ptr = new_info;

	/* signal we have to update already created pages */
	mem->callback_infos.is_changed = 1;
}

/**
 * Remove the callback for the given range of memory.
 * @param mem	Memory to set.
 * @param start	Start address (rounded to the page).
 * @param end	End address (rounded to the page).
 */
void arm_unset_range_callback(arm_memory_t *mem, arm_address_t start, arm_address_t end) {
	arm_address_t startp = (start + MEMORY_PAGE_SIZE - 1) & ~(MEMORY_PAGE_SIZE - 1);
	arm_address_t endp = (end + MEMORY_PAGE_SIZE - 1) & ~(MEMORY_PAGE_SIZE - 1);
	arm_address_t a;

	// synchronize callback information
	if (mem->callback_infos.is_changed)
		update_callback_infos(mem);

	// unset concerned page (beware the end address at 0xfffff000)
	a = startp;
	while(1) {
		memory_page_table_entry_t *page = mem_search_page(mem, a);
		if(page)
			page->info = NULL;
		if(a == endp)
			break;
		a = a + MEMORY_PAGE_SIZE;
	}
}


/**
 * Get callback data in the page containing the address.
 * @param mem		Memory to look in.
 * @param addr		Looked address.
 * @return			Found data or NULL.
 */
void *arm_get_callback_data(arm_memory_t *mem, arm_address_t addr) {
	memory_page_table_entry_t *page = mem_search_page(mem, addr);
	if(page == NULL || page->info == NULL)
		return NULL;
	else
		return page->info->callback_data;
}
